Design proposals:

* [API Redesign](proposals/APIRedesign.md)