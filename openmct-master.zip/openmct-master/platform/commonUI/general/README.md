# Directives

* `mct-scroll-x` is an attribute whose value is an assignable
  Angular expression. This two-way binds that expression to the
  horizontal scroll state of the element on which it is applied.
* `mct-scroll-y` is an attribute whose value is an assignable
  Angular expression. This two-way binds that expression to the
  vertical scroll state of the element on which it is applied.
