# Espresso Theme
A light colored theme for the Open MCT user interface.

## Installation
```js
openmct.install(openmct.plugins.Snow());
```