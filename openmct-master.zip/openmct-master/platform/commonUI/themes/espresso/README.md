# Espresso Theme
Dark theme for the Open MCT user interface.

## Installation
```js
openmct.install(openmct.plugins.Espresso());
```