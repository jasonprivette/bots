This directory contains all bundles for the Open MCT platform, as well 
as the framework which runs them.
