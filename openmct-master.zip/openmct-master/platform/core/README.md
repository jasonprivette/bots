This bundle contains core software components of Open MCT. These 
components describe MCT's information model, and are responsible for 
introducing the API and infrastructure which supports domain objects.
