Implements support for rules which determine which objects are allowed
to contain other objects, typically by type.
