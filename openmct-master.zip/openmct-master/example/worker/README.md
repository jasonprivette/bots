Example of running a Web Worker using the `workerService`.
