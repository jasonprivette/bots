This bundle is intended to serve as an example of registering
extensions which are mapped directly to built-in Angular features.

These are:
* Controllers
* Directives
* Routes
* Services
