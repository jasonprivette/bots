This directory is for example bundles, which are intended to illustrate 
how to author new software components using Open MCT.
