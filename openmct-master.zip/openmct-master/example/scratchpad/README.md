Example of using multiple persistence stores by exposing a root
object with a different space prefix.
